from PIL import Image
from PIL import ImageDraw
from PIL import ImageFont
import os


class NameTagExporter:

    def __init__(self):
        pass

    def export(
        self,
        template_path,
        output_path,
        name,
        name_x,
        name_y,
        font_path,
        font_size=36
    ):

        image = Image.open(template_path)
        print("IMAGE SIZE :", image.size)
        draw = ImageDraw.Draw(image)

        font = ImageFont.truetype(
            font_path,
            font_size
        )
        print("Nama :", name)
        print("X :", name_x)
        print("Y :", name_y)
        print("Font :", font_path)
        
        draw.text(
            (name_x, name_y),
            name,
            fill="black",
            font=font,
            anchor="mm"
        )

        os.makedirs(
            os.path.dirname(output_path),
            exist_ok=True
        )

        image.save(output_path)

        print("EXPORT BERHASIL")