from tkinter import font

from PIL import Image, ImageDraw, ImageFont
import os

from networkx import draw


class NameTagExporter:

    def __init__(self):
        pass

    def to_pixel(self, value, max_val):
        """
        Convert posisi:
        - kalau <= 1 → dianggap RELATIVE (%)
        - kalau > 1 → dianggap PIXEL
        """
        value = float(value)
        if value <= 1:
            return value * max_val
        return value

    def export(
        self,
        template_path,
        output_path,

        name_text,
        absen_text,

        name_x,
        name_y,

        absen_x,
        absen_y,

        font_path,

        name_font_size,
        absen_font_size,

        name_color,
        absen_color,
        
        preview_width,
        preview_height
    ):

        # ==========================
        # Load template
        # ==========================

        image = Image.open(template_path).convert("RGBA")
        draw = ImageDraw.Draw(image)

        img_w, img_h = image.size

        # ==========================
        # Convert posisi
        # ==========================

        name_px = float(name_x)
        name_py = float(name_y)

        absen_px = float(absen_x)
        absen_py = float(absen_y)

        # ==========================
        # Font
        # ==========================

        if not os.path.exists(font_path):
            raise FileNotFoundError(f"Font tidak ditemukan: {font_path}")

        scale_x = img_w / preview_width
        scale_y = img_h / preview_height
               
        name_x = int(name_x * scale_x)
        name_y = int(name_y * scale_y)

        absen_x = int(absen_x * scale_x)
        absen_y = int(absen_y * scale_y)
        
        scaled_name_size = int(name_font_size * scale_y)
        scaled_absen_size = int(absen_font_size * scale_y)

        name_font = ImageFont.truetype(font_path, scaled_name_size)
        absen_font = ImageFont.truetype(font_path, scaled_absen_size)

        draw.text((name_x, name_y), name_text, font=name_font, fill=name_color)
        draw.text((absen_x, absen_y), absen_text, font=absen_font, fill=absen_color)

        # ==========================
        # Debug
        # ==========================

        print("\n========== EXPORT ==========")
        print("Template :", template_path)
        print("Output   :", output_path)
        print("Ukuran   :", img_w, "x", img_h)

        print("Nama     :", name_text)
        print("Nama PX  :", name_px, name_py)

        print("Absen    :", absen_text)
        print("Absen PX :", absen_px, absen_py)

        print("============================\n")
        print("=== AFTER SCALE ===")
        print("Nama XY :", name_x, name_y)
        print("Absen XY:", absen_x, absen_y)
        print("Font Nama:", scaled_name_size)
        print("Font Absen:", scaled_absen_size)

        # ==========================
        # DRAW NAMA
        # ==========================

        draw.text(
            (name_x, name_y),
            name_text,
            fill=name_color,
            font=name_font,
            anchor="mm"
        )

        # ==========================
        # DRAW ABSEN
        # ==========================

        draw.text(
            (absen_x, absen_y),
            absen_text,
            fill=absen_color,
            font=absen_font,
            anchor="mm"
        )

        # ==========================
        # SAVE
        # ==========================

        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        image.save(output_path)

        print("✅ EXPORT BERHASIL :", output_path)